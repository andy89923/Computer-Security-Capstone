#!/bin/sh

#gdb Timeout

gdb --batch --command=test.gdb --args ./Timeout
